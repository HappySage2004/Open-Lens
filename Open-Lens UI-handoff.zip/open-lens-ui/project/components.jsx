
// OpenLens — Shared components
// Exported to window at bottom

// ─── Icons (inline SVG) ────────────────────────────────────────────────────
const Icon = ({ name, size = 16, color = "currentColor" }) => {
  const icons = {
    lens: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>,
    chevronDown: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>,
    chevronRight: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>,
    chevronUp: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="18 15 12 9 6 15"/></svg>,
    check: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2"><polyline points="20 6 9 17 4 12"/></svg>,
    circle: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><circle cx="12" cy="12" r="9"/></svg>,
    clock: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 15"/></svg>,
    spinner: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" style={{animation:"spin 1s linear infinite"}}><path d="M12 3a9 9 0 1 0 9 9" strokeLinecap="round"/></svg>,
    code: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>,
    brain: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M9 3a4 4 0 0 0-4 4v1a3 3 0 0 0 0 6v1a4 4 0 0 0 4 4h6a4 4 0 0 0 4-4v-1a3 3 0 0 0 0-6V7a4 4 0 0 0-4-4H9z"/></svg>,
    tool: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>,
    play: <svg width={size} height={size} viewBox="0 0 24 24" fill={color}><polygon points="5 3 19 12 5 21"/></svg>,
    copy: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
    fork: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="6" y1="3" x2="6" y2="15"/><path d="M18 3v4a4 4 0 0 1-4 4H6"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="6" r="3"/></svg>,
    chart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></svg>,
    table: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/></svg>,
    finding: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
    ledger: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/></svg>,
    narrative: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    warning: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
    plus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    send: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
    database: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>,
    refresh: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>,
    close: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    hypothesis: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/><circle cx="12" cy="12" r="9"/></svg>,
    dashboard: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
    history: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.95"/></svg>,
    session: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
    model: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>,
    stat: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 1 0 0 7h5a3.5 3.5 0 1 1 0 7H6"/></svg>,
    newSession: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M12 5v14M5 12h14"/></svg>,
    checkpoint: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
    contextPad: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/><path d="M17 21l2-2-2-2" strokeLinecap="round"/></svg>,
    notepad: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="4" y="3" width="16" height="18" rx="2"/><line x1="8" y1="7" x2="16" y2="7"/><line x1="8" y1="11" x2="16" y2="11"/><line x1="8" y1="15" x2="12" y2="15"/><line x1="4" y1="3" x2="4" y2="21" strokeDasharray="2 2" stroke="none"/><rect x="7" y="1" width="10" height="3" rx="1" fill={color} stroke="none" opacity="0.35"/></svg>,
    image: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
    toggleOn: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="1" y="7" width="22" height="10" rx="5"/><circle cx="16" cy="12" r="3.5" fill={color} stroke="none"/></svg>,
    toggleOff: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><rect x="1" y="7" width="22" height="10" rx="5"/><circle cx="8" cy="12" r="3.5" fill={color} stroke="none" opacity="0.45"/></svg>,
    bold: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2"><path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/></svg>,
    italic: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></svg>,
    heading: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M4 12h16M4 6v12M20 6v12"/></svg>,
    listBullet: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/><circle cx="4" cy="6" r="1.5" fill={color} stroke="none"/><circle cx="4" cy="12" r="1.5" fill={color} stroke="none"/><circle cx="4" cy="18" r="1.5" fill={color} stroke="none"/></svg>,
    upload: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>,
    gear: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
    externalLink: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>,
    undo: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>,
  };
  return icons[name] || <svg width={size} height={size} viewBox="0 0 24 24"/>;
};

// ─── Artifact type config ──────────────────────────────────────────────────
const ARTIFACT_CONFIG = {
  Chart: { icon: "chart", color: "#d4954a", bg: "rgba(212,149,74,0.1)" },
  Table: { icon: "table", color: "#0ea5e9", bg: "rgba(14,165,233,0.1)" },
  "Key Finding": { icon: "finding", color: "#f59e0b", bg: "rgba(245,158,11,0.1)" },
  "Cleaning Ledger": { icon: "ledger", color: "#10b981", bg: "rgba(16,185,129,0.1)" },
  "Hypothesis Register": { icon: "hypothesis", color: "#8b5cf6", bg: "rgba(139,92,246,0.1)" },
  Narrative: { icon: "narrative", color: "#ec4899", bg: "rgba(236,72,153,0.1)" },
  "Model Output": { icon: "model", color: "#f97316", bg: "rgba(249,115,22,0.1)" },
  "Summary Stat": { icon: "stat", color: "#14b8a6", bg: "rgba(20,184,166,0.1)" },
};

// ─── Hypothesis status badge ───────────────────────────────────────────────
const HypoStatusBadge = ({ status }) => {
  const cfg = {
    Supported: { color: "#10b981", bg: "rgba(16,185,129,0.12)", label: "Supported" },
    Active: { color: "#d4954a", bg: "rgba(212,149,74,0.12)", label: "Active" },
    Refuted: { color: "#ef4444", bg: "rgba(239,68,68,0.12)", label: "Refuted" },
    Inconclusive: { color: "#94a3b8", bg: "rgba(148,163,184,0.12)", label: "Inconclusive" },
  }[status] || { color: "#94a3b8", bg: "rgba(148,163,184,0.12)", label: status };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      fontSize: 11, fontWeight: 600, letterSpacing: "0.03em",
      color: cfg.color, background: cfg.bg,
      padding: "2px 8px", borderRadius: 99,
    }}>{cfg.label}</span>
  );
};

// ─── Step status dot ───────────────────────────────────────────────────────
const StepStatusDot = ({ status }) => {
  const cfg = {
    complete: { color: "#10b981" },
    active: { color: "#d4954a" },
    pending: { color: "#475569" },
    error: { color: "#ef4444" },
  }[status] || { color: "#94a3b8" };
  if (status === "active") {
    return (
      <span style={{
        width: 10, height: 10, borderRadius: "50%",
        background: cfg.color, flexShrink: 0, marginTop: 3,
        boxShadow: `0 0 0 3px rgba(212,149,74,0.25)`,
        animation: "pulse 2s infinite",
      }} />
    );
  }
  return (
    <span style={{
      width: 10, height: 10, borderRadius: "50%",
      background: status === "complete" ? cfg.color : "transparent",
      border: `2px solid ${cfg.color}`,
      flexShrink: 0, marginTop: 3,
    }} />
  );
};

// ─── Mock chart placeholder ─────────────────────────────────────────────────
const MockChart = ({ chartId, height = 200 }) => {
  const isRunning = chartId && chartId.includes("deal_dist");
  if (isRunning) {
    return (
      <div style={{
        height, display: "flex", alignItems: "center", justifyContent: "center",
        gap: 10, color: "var(--text-muted)", fontSize: 13,
        background: "var(--surface-2)", borderRadius: 8,
        border: "1px solid var(--border)",
      }}>
        <Icon name="spinner" size={16} color="#d4954a" />
        <span>Rendering chart…</span>
      </div>
    );
  }

  // Simple bar chart SVG
  const bars = chartId === "chart_revenue_region"
    ? [
        { label: "NA", values: [78, 62], q: "Q1" },
        { label: "EMEA", values: [55, 48], q: "Q2" },
        { label: "APAC", values: [42, 34], q: "Q3" },
        { label: "LATAM", values: [22, 24], q: "" },
      ]
    : [
        { label: "Q1", values: [60, 52] },
        { label: "Q2", values: [65, 53] },
        { label: "Q3", values: [58, 47] },
      ];

  const maxVal = 90;
  const chartH = height - 48;

  return (
    <div style={{ background: "var(--surface-2)", borderRadius: 8, padding: "16px 20px", border: "1px solid var(--border)" }}>
      <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 12, display: "flex", gap: 16 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: "#d4954a", display: "inline-block" }} />
          2025
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: "rgba(212,149,74,0.3)", display: "inline-block" }} />
          2024
        </span>
      </div>
      <svg width="100%" height={chartH} viewBox={`0 0 ${bars.length * 80} ${chartH}`} preserveAspectRatio="none">
        {bars.map((bar, i) => {
          const x = i * 80 + 10;
          const bw = 20;
          return (
            <g key={i}>
              <rect x={x} y={chartH - (bar.values[0] / maxVal) * chartH} width={bw} height={(bar.values[0] / maxVal) * chartH} fill="#d4954a" rx="2" opacity="0.9" />
              <rect x={x + bw + 3} y={chartH - (bar.values[1] / maxVal) * chartH} width={bw} height={(bar.values[1] / maxVal) * chartH} fill="rgba(212,149,74,0.3)" rx="2" />
              <text x={x + bw + 1} y={chartH + 14} textAnchor="middle" fontSize="10" fill="var(--text-muted)">{bar.label}</text>
            </g>
          );
        })}
        <line x1="0" y1={chartH} x2={bars.length * 80} y2={chartH} stroke="var(--border)" strokeWidth="1" />
      </svg>
    </div>
  );
};

// ─── Code Block ─────────────────────────────────────────────────────────────
const CodeBlock = ({ code, running, showByDefault = true }) => {
  const [visible, setVisible] = React.useState(showByDefault);
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ marginTop: 8 }}>
      <button
        onClick={() => setVisible(v => !v)}
        style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "none", border: "none", cursor: "pointer",
          color: "var(--text-muted)", fontSize: 12, fontWeight: 500, padding: 0,
        }}
      >
        <Icon name={visible ? "chevronDown" : "chevronRight"} size={13} />
        <Icon name="code" size={13} />
        <span>Code</span>
        {running && <span style={{ display: "flex", alignItems: "center", gap: 4, color: "#d4954a", marginLeft: 4 }}><Icon name="spinner" size={12} color="#d4954a" />running</span>}
      </button>
      {visible && (
        <div style={{ marginTop: 6, position: "relative" }}>
          <pre style={{
            background: "var(--code-bg)",
            border: "1px solid var(--border)",
            borderRadius: 8,
            padding: "14px 16px",
            fontSize: 12,
            lineHeight: 1.7,
            color: "var(--code-text)",
            overflowX: "auto",
            fontFamily: "'JetBrains Mono', 'Fira Mono', 'Cascadia Code', monospace",
            margin: 0,
          }}>
            <code>{code}</code>
          </pre>
          <div style={{ position: "absolute", top: 8, right: 10, display: "flex", gap: 6 }}>
            <button onClick={handleCopy} style={{ background: "var(--surface-3)", border: "1px solid var(--border)", borderRadius: 5, padding: "3px 8px", cursor: "pointer", color: "var(--text-muted)", fontSize: 11, display: "flex", alignItems: "center", gap: 4 }}>
              <Icon name="copy" size={11} />
              {copied ? "Copied!" : "Copy"}
            </button>
            <button style={{ background: "var(--surface-3)", border: "1px solid var(--border)", borderRadius: 5, padding: "3px 8px", cursor: "pointer", color: "var(--text-muted)", fontSize: 11, display: "flex", alignItems: "center", gap: 4 }}>
              <Icon name="fork" size={11} />
              Fork
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Reasoning Drawer ───────────────────────────────────────────────────────
const ReasoningDrawer = ({ reasoning, showByDefault = false }) => {
  const [open, setOpen] = React.useState(showByDefault);
  return (
    <div style={{ marginTop: 6 }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "none", border: "none", cursor: "pointer",
          color: "var(--text-muted)", fontSize: 12, fontWeight: 500, padding: 0,
        }}
      >
        <Icon name={open ? "chevronDown" : "chevronRight"} size={13} />
        <Icon name="brain" size={13} />
        <span>Reasoning</span>
      </button>
      {open && (
        <div style={{
          marginTop: 6, padding: "10px 14px",
          background: "rgba(212,149,74,0.06)",
          border: "1px solid rgba(212,149,74,0.18)",
          borderRadius: 8, fontSize: 12.5, lineHeight: 1.65,
          color: "var(--text-secondary)",
          fontStyle: "italic",
        }}>
          {reasoning}
        </div>
      )}
    </div>
  );
};

// ─── Tool Call Drawer ───────────────────────────────────────────────────────
const ToolCallDrawer = ({ toolCalls, showByDefault = false }) => {
  const [open, setOpen] = React.useState(showByDefault);
  return (
    <div style={{ marginTop: 6 }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "none", border: "none", cursor: "pointer",
          color: "var(--text-muted)", fontSize: 12, fontWeight: 500, padding: 0,
        }}
      >
        <Icon name={open ? "chevronDown" : "chevronRight"} size={13} />
        <Icon name="tool" size={13} />
        <span>Tool calls</span>
        <span style={{ fontSize: 11, color: "var(--text-muted)", background: "var(--surface-3)", borderRadius: 99, padding: "0 6px" }}>{toolCalls.length}</span>
      </button>
      {open && (
        <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 4 }}>
          {toolCalls.map((tc, i) => (
            <div key={i} style={{
              background: "var(--code-bg)", borderRadius: 7,
              border: "1px solid var(--border)", padding: "7px 12px",
              fontFamily: "monospace", fontSize: 12, color: "var(--text-secondary)",
            }}>
              <span style={{ color: "#f59e0b" }}>{tc.fn}</span>
              <span style={{ color: "var(--text-muted)" }}>({JSON.stringify(tc.args).slice(1, -1)})</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Uncertainty Flag ───────────────────────────────────────────────────────
const UncertaintyFlag = ({ flag }) => (
  <div style={{
    display: "flex", alignItems: "flex-start", gap: 8,
    background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)",
    borderRadius: 8, padding: "8px 12px", marginTop: 8,
  }}>
    <Icon name="warning" size={14} color="#f59e0b" />
    <div>
      <span style={{ fontSize: 11, fontWeight: 700, color: "#f59e0b", textTransform: "uppercase", letterSpacing: "0.05em" }}>{flag.type}</span>
      <p style={{ margin: "2px 0 0", fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.5 }}>{flag.description}</p>
    </div>
  </div>
);

// ─── Artifact Badge ─────────────────────────────────────────────────────────
const ArtifactBadge = ({ artifactId, artifacts }) => {
  const art = artifacts.find(a => a.id === artifactId);
  if (!art) return null;
  const cfg = ARTIFACT_CONFIG[art.type] || ARTIFACT_CONFIG.Chart;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      background: cfg.bg, color: cfg.color,
      border: `1px solid ${cfg.color}30`,
      borderRadius: 99, padding: "2px 10px", fontSize: 11, fontWeight: 600,
    }}>
      <Icon name={cfg.icon} size={11} color={cfg.color} />
      {art.name}
    </span>
  );
};

// ─── Scratchpad Step ─────────────────────────────────────────────────────────
const ScratchpadStep = ({ step, artifacts, mode, index }) => {
  const [expanded, setExpanded] = React.useState(step.status === "active");
  const isAnalyst = mode === "analyst";

  return (
    <div style={{
      background: "var(--surface-1)",
      border: step.status === "active" ? "1px solid rgba(212,149,74,0.35)" : "1px solid var(--border)",
      borderRadius: 10, overflow: "hidden",
      boxShadow: step.status === "active" ? "0 0 0 3px rgba(212,149,74,0.08)" : "none",
    }}>
      {/* Step header */}
      <div
        onClick={() => setExpanded(v => !v)}
        style={{
          display: "flex", alignItems: "flex-start", gap: 12,
          padding: "12px 16px", cursor: "pointer",
          background: step.status === "active" ? "rgba(212,149,74,0.04)" : "transparent",
        }}
      >
        <StepStatusDot status={step.status} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: "var(--text-muted)", letterSpacing: "0.04em" }}>
              STEP {String(index + 1).padStart(2, "0")}
            </span>
            {step.status === "active" && (
              <span style={{ fontSize: 11, color: "#d4954a", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>
                <Icon name="spinner" size={11} color="#d4954a" /> Running
              </span>
            )}
          </div>
          <p style={{ margin: "3px 0 0", fontSize: 13.5, fontWeight: 500, color: "var(--text-primary)", lineHeight: 1.4 }}>
            {step.title}
          </p>
          {!expanded && step.artifacts.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginTop: 7 }}>
              {step.artifacts.map(aid => <ArtifactBadge key={aid} artifactId={aid} artifacts={artifacts} />)}
            </div>
          )}
        </div>
        <Icon name={expanded ? "chevronUp" : "chevronDown"} size={15} color="var(--text-muted)" />
      </div>

      {/* Expanded body */}
      {expanded && (
        <div style={{ padding: "0 16px 16px", borderTop: "1px solid var(--border)" }}>
          <div style={{ height: 12 }} />

          {/* Reasoning & tool calls — analyst default expanded, business collapsed */}
          <ReasoningDrawer reasoning={step.reasoning} showByDefault={isAnalyst} />
          {isAnalyst && <ToolCallDrawer toolCalls={step.tool_calls} showByDefault={false} />}

          {/* Code block */}
          <CodeBlock code={step.code} running={step.status === "active"} showByDefault={isAnalyst} />

          {/* Output */}
          {step.output && (
            <div style={{ marginTop: 10 }}>
              {step.output.type === "text" && (
                <div style={{
                  background: "var(--surface-2)", borderRadius: 8, border: "1px solid var(--border)",
                  padding: "10px 14px", fontFamily: "monospace", fontSize: 12,
                  color: "var(--text-secondary)", lineHeight: 1.6, whiteSpace: "pre-wrap",
                }}>
                  {step.output.content}
                </div>
              )}
              {step.output.type === "chart" && (
                <MockChart chartId={step.output.chartId} running={step.output.running} height={220} />
              )}
              {step.output.type === "cleaning" && (
                <div style={{
                  background: "rgba(16,185,129,0.07)", border: "1px solid rgba(16,185,129,0.25)",
                  borderRadius: 8, padding: "10px 14px", fontSize: 12.5, color: "var(--text-secondary)",
                  display: "flex", alignItems: "center", gap: 8,
                }}>
                  <Icon name="check" size={14} color="#10b981" />
                  {step.output.content}
                </div>
              )}
            </div>
          )}

          {/* Uncertainty flags */}
          {step.uncertainty_flags.map((f, i) => <UncertaintyFlag key={i} flag={f} />)}

          {/* Artifact badges */}
          {step.artifacts.length > 0 && (
            <div style={{ marginTop: 12 }}>
              <span style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 600, letterSpacing: "0.04em" }}>ARTIFACTS PRODUCED</span>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 6 }}>
                {step.artifacts.map(aid => <ArtifactBadge key={aid} artifactId={aid} artifacts={artifacts} />)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

Object.assign(window, {
  Icon,
  ARTIFACT_CONFIG,
  HypoStatusBadge,
  StepStatusDot,
  StepDot: StepStatusDot,
  MockChart,
  MockBarChart: MockChart,
  CodeBlock,
  ReasoningDrawer,
  ToolCallDrawer,
  ToolDrawer: ToolCallDrawer,
  UncertaintyFlag,
  ArtifactBadge,
  ScratchpadStep,
});
